import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Image,
  TouchableOpacity,
} from 'react-native';
import { 
  BookOpen, 
  MapPin, 
  Calendar, 
  Music, 
  Utensils, 
  Landmark,
  TrendingUp,
  Star
} from 'lucide-react-native';
import FeatureCard from '@/components/FeatureCard';
import GradientBackground from '@/components/GradientBackground';

export default function DiscoverTab() {
  const featuredContent = [
    {
      id: '1',
      title: 'Myanmar History',
      description: 'Explore the rich history of Myanmar from ancient kingdoms to modern times',
      icon: BookOpen,
      color: '#F59E0B',
    },
    {
      id: '2',
      title: 'Cultural Heritage',
      description: 'Discover Myanmar\'s diverse cultural traditions and customs',
      icon: Landmark,
      color: '#8B5CF6',
    },
    {
      id: '3',
      title: 'Traditional Cuisine',
      description: 'Learn about Myanmar\'s delicious and diverse culinary heritage',
      icon: Utensils,
      color: '#EF4444',
    },
    {
      id: '4',
      title: 'Festivals & Events',
      description: 'Experience Myanmar\'s vibrant festivals and celebrations',
      icon: Calendar,
      color: '#10B981',
    },
    {
      id: '5',
      title: 'Music & Arts',
      description: 'Explore traditional Myanmar music, dance, and artistic expressions',
      icon: Music,
      color: '#EC4899',
    },
    {
      id: '6',
      title: 'Places to Visit',
      description: 'Discover amazing destinations and hidden gems across Myanmar',
      icon: MapPin,
      color: '#06B6D4',
    },
  ];

  const trendingTopics = [
    'Bagan Archaeological Zone',
    'Myanmar Traditional Puppetry',
    'Inle Lake Culture',
    'Mandalay Royal Palace',
    'Myanmar Tea Culture',
  ];

  return (
    <SafeAreaView style={styles.container}>
      <GradientBackground colors={['#F59E0B', '#D97706']}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Discover</Text>
          <Text style={styles.headerSubtitle}>Explore Myanmar's rich culture</Text>
        </View>
      </GradientBackground>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.heroSection}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/2739664/pexels-photo-2739664.jpeg' }}
            style={styles.heroImage}
          />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroTitle}>Welcome to Myanmar</Text>
            <Text style={styles.heroSubtitle}>
              Discover the Golden Land's treasures
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Star size={20} color="#F59E0B" />
            <Text style={styles.sectionTitle}>Featured Topics</Text>
          </View>
          {featuredContent.map((item) => (
            <FeatureCard
              key={item.id}
              title={item.title}
              description={item.description}
              icon={item.icon}
              color={item.color}
            />
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <TrendingUp size={20} color="#10B981" />
            <Text style={styles.sectionTitle}>Trending Now</Text>
          </View>
          <View style={styles.trendingContainer}>
            {trendingTopics.map((topic, index) => (
              <TouchableOpacity key={index} style={styles.trendingItem}>
                <Text style={styles.trendingText}>#{topic}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Did You Know?</Text>
          <View style={styles.factCard}>
            <Text style={styles.factText}>
              Myanmar has over 135 officially recognized ethnic groups, making it one of the most ethnically diverse countries in Southeast Asia. Each group has its own unique traditions, languages, and cultural practices.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Facts</Text>
          <View style={styles.quickFactsContainer}>
            <View style={styles.quickFact}>
              <Text style={styles.quickFactNumber}>676,578</Text>
              <Text style={styles.quickFactLabel}>Square Kilometers</Text>
            </View>
            <View style={styles.quickFact}>
              <Text style={styles.quickFactNumber}>54M+</Text>
              <Text style={styles.quickFactLabel}>Population</Text>
            </View>
            <View style={styles.quickFact}>
              <Text style={styles.quickFactNumber}>135+</Text>
              <Text style={styles.quickFactLabel}>Ethnic Groups</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E5E7EB',
  },
  content: {
    flex: 1,
  },
  heroSection: {
    position: 'relative',
    height: 200,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  heroOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 20,
  },
  heroTitle: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  heroSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E5E7EB',
  },
  section: {
    marginVertical: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginLeft: 8,
  },
  trendingContainer: {
    paddingHorizontal: 16,
  },
  trendingItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginVertical: 4,
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  trendingText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#10B981',
  },
  factCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  factText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#4B5563',
    lineHeight: 24,
  },
  quickFactsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  quickFact: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  quickFactNumber: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#F59E0B',
    marginBottom: 4,
  },
  quickFactLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
  },
});