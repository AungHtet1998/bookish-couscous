import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
  Alert,
  TextInput,
} from 'react-native';
import { CreditCard, Smartphone, Building2, Wallet, Star, Shield, CircleCheck as CheckCircle, ArrowRight, Plus, History, Gift, Zap } from 'lucide-react-native';
import GradientBackground from '@/components/GradientBackground';

interface PaymentMethod {
  id: string;
  name: string;
  type: 'bank' | 'mobile' | 'digital' | 'card';
  icon: string;
  description: string;
  fees: string;
  processingTime: string;
  isPopular?: boolean;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  period: string;
  features: string[];
  isPopular?: boolean;
  discount?: string;
}

export default function PaymentsTab() {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);

  const paymentMethods: PaymentMethod[] = [
    {
      id: 'kbz-pay',
      name: 'KBZ Pay',
      type: 'mobile',
      icon: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg',
      description: 'Myanmar\'s leading mobile payment platform',
      fees: 'Free for transfers under 50,000 MMK',
      processingTime: 'Instant',
      isPopular: true,
    },
    {
      id: 'wave-money',
      name: 'Wave Money',
      type: 'mobile',
      icon: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg',
      description: 'Popular mobile money service in Myanmar',
      fees: '1% transaction fee',
      processingTime: 'Instant',
      isPopular: true,
    },
    {
      id: 'cb-bank',
      name: 'CB Bank',
      type: 'bank',
      icon: 'https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg',
      description: 'One of Myanmar\'s largest commercial banks',
      fees: '500 MMK per transaction',
      processingTime: '1-2 business days',
    },
    {
      id: 'aya-bank',
      name: 'AYA Bank',
      type: 'bank',
      icon: 'https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg',
      description: 'Leading private bank in Myanmar',
      fees: '1,000 MMK per transaction',
      processingTime: '1-2 business days',
    },
    {
      id: 'kbz-bank',
      name: 'KBZ Bank',
      type: 'bank',
      icon: 'https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg',
      description: 'Myanmar\'s largest private bank',
      fees: '500 MMK per transaction',
      processingTime: '1-2 business days',
    },
    {
      id: 'yoma-bank',
      name: 'Yoma Bank',
      type: 'bank',
      icon: 'https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg',
      description: 'Established commercial bank',
      fees: '750 MMK per transaction',
      processingTime: '1-2 business days',
    },
    {
      id: 'uab-bank',
      name: 'UAB Bank',
      type: 'bank',
      icon: 'https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg',
      description: 'United Amara Bank',
      fees: '600 MMK per transaction',
      processingTime: '1-2 business days',
    },
    {
      id: 'true-money',
      name: 'TrueMoney',
      type: 'digital',
      icon: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg',
      description: 'Digital wallet service',
      fees: '2% transaction fee',
      processingTime: 'Instant',
    },
    {
      id: 'visa-card',
      name: 'Visa Card',
      type: 'card',
      icon: 'https://images.pexels.com/photos/164501/pexels-photo-164501.jpeg',
      description: 'International credit/debit cards',
      fees: '3% + currency conversion',
      processingTime: 'Instant',
    },
    {
      id: 'mastercard',
      name: 'Mastercard',
      type: 'card',
      icon: 'https://images.pexels.com/photos/164501/pexels-photo-164501.jpeg',
      description: 'International credit/debit cards',
      fees: '3% + currency conversion',
      processingTime: 'Instant',
    },
  ];

  const subscriptionPlans: SubscriptionPlan[] = [
    {
      id: 'basic',
      name: 'Basic',
      price: 5000,
      currency: 'MMK',
      period: 'month',
      features: [
        '100 AI conversations per day',
        'Basic search functionality',
        'Image analysis (10 per day)',
        'Standard support',
      ],
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 15000,
      currency: 'MMK',
      period: 'month',
      features: [
        'Unlimited AI conversations',
        'Advanced search with filters',
        'Unlimited image analysis',
        'Priority support',
        'Offline content access',
        'Custom AI training',
      ],
      isPopular: true,
      discount: 'Most Popular',
    },
    {
      id: 'pro',
      name: 'Professional',
      price: 35000,
      currency: 'MMK',
      period: 'month',
      features: [
        'Everything in Premium',
        'API access for businesses',
        'White-label solutions',
        'Dedicated account manager',
        'Custom integrations',
        'Advanced analytics',
      ],
    },
  ];

  const getPaymentMethodIcon = (type: string) => {
    switch (type) {
      case 'mobile':
        return Smartphone;
      case 'bank':
        return Building2;
      case 'digital':
        return Wallet;
      case 'card':
        return CreditCard;
      default:
        return CreditCard;
    }
  };

  const handlePaymentMethodSelect = (methodId: string) => {
    setSelectedPaymentMethod(methodId);
  };

  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handleProceedToPayment = () => {
    if (!selectedPaymentMethod || !selectedPlan) {
      Alert.alert('Selection Required', 'Please select both a payment method and subscription plan.');
      return;
    }
    setShowPaymentForm(true);
  };

  const handlePayment = () => {
    Alert.alert(
      'Payment Successful',
      'Your subscription has been activated successfully!',
      [{ text: 'OK', onPress: () => setShowPaymentForm(false) }]
    );
  };

  if (showPaymentForm) {
    const selectedMethod = paymentMethods.find(m => m.id === selectedPaymentMethod);
    const selectedPlanData = subscriptionPlans.find(p => p.id === selectedPlan);

    return (
      <SafeAreaView style={styles.container}>
        <GradientBackground colors={['#10B981', '#059669']}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => setShowPaymentForm(false)}>
              <Text style={styles.backButton}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Complete Payment</Text>
            <Text style={styles.headerSubtitle}>Secure payment processing</Text>
          </View>
        </GradientBackground>

        <ScrollView style={styles.content}>
          <View style={styles.paymentSummary}>
            <Text style={styles.sectionTitle}>Payment Summary</Text>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Plan:</Text>
              <Text style={styles.summaryValue}>{selectedPlanData?.name}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Amount:</Text>
              <Text style={styles.summaryValue}>
                {selectedPlanData?.price.toLocaleString()} {selectedPlanData?.currency}
              </Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Payment Method:</Text>
              <Text style={styles.summaryValue}>{selectedMethod?.name}</Text>
            </View>
          </View>

          <View style={styles.paymentForm}>
            <Text style={styles.sectionTitle}>Payment Details</Text>
            
            {selectedMethod?.type === 'mobile' && (
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Mobile Number</Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="09xxxxxxxxx"
                  keyboardType="phone-pad"
                />
              </View>
            )}

            {selectedMethod?.type === 'bank' && (
              <>
                <View style={styles.formGroup}>
                  <Text style={styles.formLabel}>Account Number</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="Enter your account number"
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.formGroup}>
                  <Text style={styles.formLabel}>Account Holder Name</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="Enter account holder name"
                  />
                </View>
              </>
            )}

            {selectedMethod?.type === 'card' && (
              <>
                <View style={styles.formGroup}>
                  <Text style={styles.formLabel}>Card Number</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="1234 5678 9012 3456"
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.formRow}>
                  <View style={styles.formGroupHalf}>
                    <Text style={styles.formLabel}>Expiry Date</Text>
                    <TextInput
                      style={styles.formInput}
                      placeholder="MM/YY"
                      keyboardType="numeric"
                    />
                  </View>
                  <View style={styles.formGroupHalf}>
                    <Text style={styles.formLabel}>CVV</Text>
                    <TextInput
                      style={styles.formInput}
                      placeholder="123"
                      keyboardType="numeric"
                      secureTextEntry
                    />
                  </View>
                </View>
              </>
            )}

            <TouchableOpacity style={styles.payButton} onPress={handlePayment}>
              <Shield size={20} color="#FFFFFF" />
              <Text style={styles.payButtonText}>
                Pay {selectedPlanData?.price.toLocaleString()} {selectedPlanData?.currency}
              </Text>
            </TouchableOpacity>

            <View style={styles.securityNote}>
              <Shield size={16} color="#10B981" />
              <Text style={styles.securityText}>
                Your payment is secured with 256-bit SSL encryption
              </Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <GradientBackground colors={['#10B981', '#059669']}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Payments</Text>
          <Text style={styles.headerSubtitle}>Upgrade your Myanmar AI experience</Text>
        </View>
      </GradientBackground>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickAction}>
            <History size={24} color="#10B981" />
            <Text style={styles.quickActionText}>Transaction History</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickAction}>
            <Gift size={24} color="#EC4899" />
            <Text style={styles.quickActionText}>Redeem Code</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Your Plan</Text>
          {subscriptionPlans.map((plan) => (
            <TouchableOpacity
              key={plan.id}
              style={[
                styles.planCard,
                selectedPlan === plan.id && styles.planCardSelected,
                plan.isPopular && styles.planCardPopular,
              ]}
              onPress={() => handlePlanSelect(plan.id)}
            >
              {plan.isPopular && (
                <View style={styles.popularBadge}>
                  <Star size={12} color="#FFFFFF" />
                  <Text style={styles.popularText}>{plan.discount}</Text>
                </View>
              )}
              
              <View style={styles.planHeader}>
                <Text style={styles.planName}>{plan.name}</Text>
                <View style={styles.planPrice}>
                  <Text style={styles.planPriceAmount}>
                    {plan.price.toLocaleString()}
                  </Text>
                  <Text style={styles.planPriceCurrency}>
                    {plan.currency}/{plan.period}
                  </Text>
                </View>
              </View>

              <View style={styles.planFeatures}>
                {plan.features.map((feature, index) => (
                  <View key={index} style={styles.planFeature}>
                    <CheckCircle size={16} color="#10B981" />
                    <Text style={styles.planFeatureText}>{feature}</Text>
                  </View>
                ))}
              </View>

              {selectedPlan === plan.id && (
                <View style={styles.selectedIndicator}>
                  <CheckCircle size={20} color="#10B981" />
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Methods</Text>
          <Text style={styles.sectionSubtitle}>
            Choose your preferred payment method for Myanmar
          </Text>

          <View style={styles.paymentMethodsGrid}>
            {paymentMethods.map((method) => {
              const IconComponent = getPaymentMethodIcon(method.type);
              return (
                <TouchableOpacity
                  key={method.id}
                  style={[
                    styles.paymentMethodCard,
                    selectedPaymentMethod === method.id && styles.paymentMethodSelected,
                  ]}
                  onPress={() => handlePaymentMethodSelect(method.id)}
                >
                  {method.isPopular && (
                    <View style={styles.popularMethodBadge}>
                      <Text style={styles.popularMethodText}>Popular</Text>
                    </View>
                  )}
                  
                  <View style={styles.paymentMethodIcon}>
                    <IconComponent size={24} color="#6B7280" />
                  </View>
                  
                  <Text style={styles.paymentMethodName}>{method.name}</Text>
                  <Text style={styles.paymentMethodDescription}>
                    {method.description}
                  </Text>
                  
                  <View style={styles.paymentMethodDetails}>
                    <Text style={styles.paymentMethodFees}>
                      Fees: {method.fees}
                    </Text>
                    <Text style={styles.paymentMethodTime}>
                      {method.processingTime}
                    </Text>
                  </View>

                  {selectedPaymentMethod === method.id && (
                    <View style={styles.selectedMethodIndicator}>
                      <CheckCircle size={16} color="#10B981" />
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <TouchableOpacity
            style={[
              styles.proceedButton,
              (!selectedPaymentMethod || !selectedPlan) && styles.proceedButtonDisabled,
            ]}
            onPress={handleProceedToPayment}
            disabled={!selectedPaymentMethod || !selectedPlan}
          >
            <Zap size={20} color="#FFFFFF" />
            <Text style={styles.proceedButtonText}>Proceed to Payment</Text>
            <ArrowRight size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        <View style={styles.trustIndicators}>
          <View style={styles.trustItem}>
            <Shield size={20} color="#10B981" />
            <Text style={styles.trustText}>Bank-level Security</Text>
          </View>
          <View style={styles.trustItem}>
            <CheckCircle size={20} color="#10B981" />
            <Text style={styles.trustText}>Trusted by 100K+ Users</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E5E7EB',
  },
  backButton: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    alignSelf: 'flex-start',
    marginBottom: 10,
  },
  content: {
    flex: 1,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 12,
  },
  quickAction: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  quickActionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#1F2937',
    marginTop: 8,
    textAlign: 'center',
  },
  section: {
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginBottom: 8,
    paddingHorizontal: 16,
  },
  sectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  planCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    position: 'relative',
  },
  planCardSelected: {
    borderColor: '#10B981',
  },
  planCardPopular: {
    borderColor: '#F59E0B',
  },
  popularBadge: {
    position: 'absolute',
    top: -8,
    right: 16,
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  popularText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 4,
  },
  planHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  planName: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#1F2937',
  },
  planPrice: {
    alignItems: 'flex-end',
  },
  planPriceAmount: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#10B981',
  },
  planPriceCurrency: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  planFeatures: {
    gap: 8,
  },
  planFeature: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  planFeatureText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#4B5563',
    marginLeft: 8,
    flex: 1,
  },
  selectedIndicator: {
    position: 'absolute',
    top: 16,
    right: 16,
  },
  paymentMethodsGrid: {
    paddingHorizontal: 16,
    gap: 12,
  },
  paymentMethodCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    position: 'relative',
  },
  paymentMethodSelected: {
    borderColor: '#10B981',
    backgroundColor: '#F0FDF4',
  },
  popularMethodBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#EC4899',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  popularMethodText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  paymentMethodIcon: {
    width: 48,
    height: 48,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  paymentMethodName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
  },
  paymentMethodDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 8,
  },
  paymentMethodDetails: {
    gap: 2,
  },
  paymentMethodFees: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: '#059669',
  },
  paymentMethodTime: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  selectedMethodIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
  },
  proceedButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    marginHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  proceedButtonDisabled: {
    backgroundColor: '#9CA3AF',
  },
  proceedButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  trustIndicators: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingVertical: 24,
    gap: 24,
  },
  trustItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  trustText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  paymentSummary: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 16,
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  summaryLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  summaryValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  paymentForm: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 16,
  },
  formRow: {
    flexDirection: 'row',
    gap: 12,
  },
  formGroupHalf: {
    flex: 1,
  },
  formLabel: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 8,
  },
  formInput: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    backgroundColor: '#FFFFFF',
  },
  payButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 16,
  },
  payButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    gap: 8,
  },
  securityText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
});