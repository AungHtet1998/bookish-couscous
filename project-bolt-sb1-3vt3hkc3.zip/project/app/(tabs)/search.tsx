import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { Search, Filter, Globe, Clock } from 'lucide-react-native';
import SearchCard from '@/components/SearchCard';
import GradientBackground from '@/components/GradientBackground';

interface SearchResult {
  id: string;
  title: string;
  description: string;
  url: string;
  imageUrl?: string;
}

export default function SearchTab() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const recentSearches = [
    'Myanmar history',
    'Yangon weather',
    'Traditional Myanmar food',
    'Myanmar festivals',
  ];

  const trendingTopics = [
    {
      id: '1',
      title: 'Myanmar Traditional Arts and Crafts',
      description: 'Explore the rich heritage of Myanmar\'s traditional arts, including lacquerware, textiles, and wood carving techniques passed down through generations.',
      url: 'myanmar-arts.com',
      imageUrl: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg',
    },
    {
      id: '2',
      title: 'Bagan Archaeological Zone',
      description: 'Discover the ancient city of Bagan with over 2,000 Buddhist temples and pagodas, a UNESCO World Heritage Site showcasing Myanmar\'s architectural marvels.',
      url: 'bagan-heritage.org',
      imageUrl: 'https://images.pexels.com/photos/2739664/pexels-photo-2739664.jpeg',
    },
    {
      id: '3',
      title: 'Myanmar Cuisine Guide',
      description: 'A comprehensive guide to Myanmar\'s diverse culinary traditions, from mohinga to tea leaf salad, exploring regional specialties and cooking techniques.',
      url: 'myanmar-food.com',
      imageUrl: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    },
  ];

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      // Simulate search API call
      setTimeout(() => {
        const mockResults: SearchResult[] = [
          {
            id: '1',
            title: `Results for "${searchQuery}"`,
            description: 'Here are the most relevant results based on your search query. Myanmar AI provides comprehensive information about various topics.',
            url: 'myanmar-ai.com',
            imageUrl: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg',
          },
          {
            id: '2',
            title: 'Related Information',
            description: 'Additional context and related information that might be helpful for your research and understanding of the topic.',
            url: 'info.myanmar.com',
            imageUrl: 'https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg',
          },
        ];
        setSearchResults(mockResults);
        setIsSearching(false);
      }, 1500);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <GradientBackground colors={['#4F46E5', '#7C3AED']}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Search</Text>
          <Text style={styles.headerSubtitle}>Discover knowledge about Myanmar</Text>
        </View>
      </GradientBackground>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color="#6B7280" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search anything about Myanmar..."
            placeholderTextColor="#9CA3AF"
            onSubmitEditing={handleSearch}
          />
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={18} color="#6B7280" />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity 
          style={styles.searchButton} 
          onPress={handleSearch}
          disabled={isSearching}
        >
          <Text style={styles.searchButtonText}>
            {isSearching ? 'Searching...' : 'Search'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {searchResults.length > 0 ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Search Results</Text>
            {searchResults.map((result) => (
              <SearchCard
                key={result.id}
                title={result.title}
                description={result.description}
                url={result.url}
                imageUrl={result.imageUrl}
              />
            ))}
          </View>
        ) : (
          <>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Clock size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Recent Searches</Text>
              </View>
              <View style={styles.recentSearches}>
                {recentSearches.map((search, index) => (
                  <TouchableOpacity 
                    key={index} 
                    style={styles.recentSearchItem}
                    onPress={() => setSearchQuery(search)}
                  >
                    <Text style={styles.recentSearchText}>{search}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Globe size={20} color="#6B7280" />
                <Text style={styles.sectionTitle}>Trending Topics</Text>
              </View>
              {trendingTopics.map((topic) => (
                <SearchCard
                  key={topic.id}
                  title={topic.title}
                  description={topic.description}
                  url={topic.url}
                  imageUrl={topic.imageUrl}
                />
              ))}
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 20,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E5E7EB',
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  filterButton: {
    padding: 8,
  },
  searchButton: {
    backgroundColor: '#6366F1',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  content: {
    flex: 1,
  },
  section: {
    marginVertical: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#1F2937',
    marginLeft: 8,
  },
  recentSearches: {
    paddingHorizontal: 16,
  },
  recentSearchItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginVertical: 4,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  recentSearchText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
});